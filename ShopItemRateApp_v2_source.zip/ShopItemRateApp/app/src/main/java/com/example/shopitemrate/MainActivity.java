package com.example.shopitemrate;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<Item> items = new ArrayList<>();
    SharedPreferences sp;
    final int BLUE = Color.rgb(25, 88, 170);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("shop_rate_data", MODE_PRIVATE);
        load();
        showLogin();
    }

    TextView tv(String s, int z) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(z); t.setTextColor(Color.DKGRAY);
        t.setPadding(18, 14, 18, 14); return t;
    }
    Button btn(String s) { Button b = new Button(this); b.setText(s); return b; }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(246,248,251));
        TextView bar = tv(title, 21); bar.setTextColor(Color.WHITE); bar.setBackgroundColor(BLUE);
        bar.setPadding(20,24,10,24); root.addView(bar);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,8,12,8);
        ScrollView sv = new ScrollView(this); sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    void showLogin() {
        base("Shop Item Rate Management");
        content.setPadding(22,45,22,20); content.addView(tv("Login / Sign Up",28));
        EditText name = new EditText(this); name.setHint("Your name / shop name"); content.addView(name);
        Button b = btn("Continue"); content.addView(b);
        b.setOnClickListener(v -> showDashboard());
    }

    void nav() {
        LinearLayout n = new LinearLayout(this); n.setGravity(Gravity.CENTER); n.setBackgroundColor(Color.WHITE);
        String[] a={"Dashboard","Add Item","Items","Reports","Settings"};
        for(String x:a){ Button b=btn(x); n.addView(b,new LinearLayout.LayoutParams(0,68,1));
            b.setOnClickListener(v->{ if(x.equals("Dashboard"))showDashboard(); else if(x.equals("Add Item"))showAdd(); else if(x.equals("Items"))showItems(); else if(x.equals("Reports"))showReports(); else showSettings(); }); }
        root.addView(n);
    }

    void showDashboard(){
        base("Dashboard"); content.addView(tv("Shop Item Rate Management",27));
        content.addView(tv("Total Items: "+items.size(),19));
        content.addView(tv("Quickly manage item prices, categories and rate history.",16));
        Button add=btn("+ Add New Item"); content.addView(add); add.setOnClickListener(v->showAdd());
        Button list=btn("View All Items"); content.addView(list); list.setOnClickListener(v->showItems()); nav();
    }

    void showAdd(){
        base("Add Item");
        EditText n=new EditText(this); n.setHint("Item name"); content.addView(n);
        EditText c=new EditText(this); c.setHint("Category (e.g. Grocery, Hardware)"); content.addView(c);
        EditText r=new EditText(this); r.setHint("Current rate (₹)"); r.setInputType(2|8192); content.addView(r);
        Button saveBtn=btn("Save Item"); content.addView(saveBtn);
        saveBtn.setOnClickListener(v->{ if(n.getText().toString().trim().isEmpty()){n.setError("Enter item name");return;}
            Item it=new Item(n.getText().toString().trim(),c.getText().toString().trim(),r.getText().toString().trim());
            it.history.add(new Rate(it.rate,now())); items.add(it); save(); showItems(); }); nav();
    }

    void showItems(){
        base("Items List");
        EditText search=new EditText(this); search.setHint("Search item or category..."); content.addView(search);
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        Runnable refresh=()->{ list.removeAllViews(); String q=search.getText().toString().toLowerCase(Locale.getDefault());
            if(items.size()==0){list.addView(tv("No items yet. Tap Add Item to create one.",18));return;}
            for(int i=0;i<items.size();i++){ Item it=items.get(i); if(!q.isEmpty() && !(it.name.toLowerCase().contains(q)||it.category.toLowerCase().contains(q)))continue;
                final int ix=i; LinearLayout row=new LinearLayout(this); row.setPadding(6,7,6,7);
                TextView t=tv(it.name+"\n"+(it.category.isEmpty()?"Uncategorized":it.category)+"  •  ₹"+it.rate,17); row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
                Button d=btn("Details"); row.addView(d); list.addView(row); d.setOnClickListener(v->showDetails(ix));
            }
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){refresh.run();} public void afterTextChanged(android.text.Editable e){}});
        refresh.run(); nav();
    }

    void showDetails(int i){
        Item it=items.get(i); base("Item Details"); content.addView(tv(it.name,28));
        content.addView(tv("Category: "+(it.category.isEmpty()?"Uncategorized":it.category),17));
        content.addView(tv("Current Rate: ₹"+it.rate,21));
        content.addView(tv("Last Updated: "+it.date,16));
        Button edit=btn("Update Rate"); content.addView(edit);
        edit.setOnClickListener(v->{ EditText r=new EditText(this); r.setHint("New rate (₹)"); r.setInputType(2|8192);
            new AlertDialog.Builder(this).setTitle("Update Rate").setView(r).setPositiveButton("Save",(d,w)->{
                String nr=r.getText().toString().trim(); if(nr.isEmpty())return; it.rate=nr; it.date=now(); it.history.add(new Rate(nr,it.date)); save(); showDetails(i);
            }).setNegativeButton("Cancel",null).show(); });
        Button hist=btn("View Rate History"); content.addView(hist); hist.setOnClickListener(v->showHistory(it));
        Button del=btn("Delete Item"); content.addView(del); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete item?").setMessage(it.name).setPositiveButton("Delete",(d,w)->{items.remove(i);save();showItems();}).setNegativeButton("Cancel",null).show()); nav();
    }

    void showHistory(Item it){
        base("Rate History"); content.addView(tv(it.name,26));
        if(it.history.size()==0){content.addView(tv("No rate changes recorded.",17));}
        else for(int j=it.history.size()-1;j>=0;j--){Rate h=it.history.get(j); content.addView(tv("₹"+h.rate+"   •   "+h.date,18));}
        nav();
    }

    void showReports(){
        base("Reports & Filters"); content.addView(tv("Reports",27));
        content.addView(tv("Total Items: "+items.size(),18));
        HashMap<String,Integer> cats=new HashMap<>();
        for(Item it:items){String c=it.category.isEmpty()?"Uncategorized":it.category;cats.put(c,cats.containsKey(c)?cats.get(c)+1:1);}
        content.addView(tv("Categories: "+cats.size(),18));
        for(String c:cats.keySet())content.addView(tv(c+" — "+cats.get(c)+" item(s)",17));
        content.addView(tv("\nCurrent Rates",22));
        for(Item it:items)content.addView(tv(it.name+" — ₹"+it.rate,17)); nav();
    }

    void showSettings(){
        base("Settings & Backup"); content.addView(tv("Settings & Backup",26));
        Button ex=btn("Export Backup"); content.addView(ex); ex.setOnClickListener(v->{
            StringBuilder s=new StringBuilder(); for(Item it:items){s.append(it.name).append("|").append(it.category).append("|").append(it.rate).append("|").append(it.date).append("\n");}
            new AlertDialog.Builder(this).setTitle("Backup Preview").setMessage(s.length()==0?"No data":s.toString()).setPositiveButton("OK",null).show(); });
        Button clear=btn("Clear All Items"); content.addView(clear); clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Clear all items?").setMessage("This cannot be undone.").setPositiveButton("Clear",(d,w)->{items.clear();save();showDashboard();}).setNegativeButton("Cancel",null).show());
        content.addView(tv("App data is stored locally on this device in this version.",15)); nav();
    }

    String now(){return new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date());}
    void save(){
        SharedPreferences.Editor e=sp.edit().clear(); e.putInt("n",items.size());
        for(int i=0;i<items.size();i++){Item x=items.get(i);e.putString("name"+i,x.name).putString("cat"+i,x.category).putString("rate"+i,x.rate).putString("date"+i,x.date).putInt("hn"+i,x.history.size());
            for(int j=0;j<x.history.size();j++){e.putString("hr"+i+"_"+j,x.history.get(j).rate).putString("hd"+i+"_"+j,x.history.get(j).date);}}
        e.apply();
    }
    void load(){
        int n=sp.getInt("n",0); for(int i=0;i<n;i++){Item x=new Item(sp.getString("name"+i,""),sp.getString("cat"+i,""),sp.getString("rate"+i,""));x.date=sp.getString("date"+i,"");int hn=sp.getInt("hn"+i,0);for(int j=0;j<hn;j++)x.history.add(new Rate(sp.getString("hr"+i+"_"+j,""),sp.getString("hd"+i+"_"+j,"")));items.add(x);}
    }
    static class Item{String name,category,rate,date;ArrayList<Rate> history=new ArrayList<>();Item(String n,String c,String r){name=n;category=c;rate=r;date=new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date());}}
    static class Rate{String rate,date;Rate(String r,String d){rate=r;date=d;}}
}
